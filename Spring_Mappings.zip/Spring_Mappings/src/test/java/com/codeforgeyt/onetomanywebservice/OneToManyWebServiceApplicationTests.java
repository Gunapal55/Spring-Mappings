package com.codeforgeyt.onetomanywebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManyWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
