# one-to-many-web-service
Hibernate one to many web service with rest endpoints and spring boot admin

# Related components
Works with Spring Boot Admin app spring-boot-admin-server

# YouTube

Watch the tutorial on YouTube

[![Watch the tutorial on YouTube](https://img.youtube.com/vi/eQsXQBiXXsg/maxresdefault.jpg)](https://youtu.be/eQsXQBiXXsg)

[![Watch the tutorial on YouTube](https://img.youtube.com/vi/OpX8RBvnN-c/maxresdefault.jpg)](https://youtu.be/OpX8RBvnN-c)

[![Watch the tutorial on YouTube](https://img.youtube.com/vi/Ly79YDERpas/maxresdefault.jpg)](https://youtu.be/Ly79YDERpas)

